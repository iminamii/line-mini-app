import { RoastTemplateForm } from "@/components/roast-template-form"
import { AppLogo } from "@/components/app-logo"

export default function TemplatePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50 p-4">
      <div className="mx-auto max-w-md">
        <div className="mb-6 flex justify-center">
          <AppLogo />
        </div>
        <h2 className="mb-4 text-center text-lg font-semibold text-amber-800">焙煎テンプレート作成</h2>
        <RoastTemplateForm />
      </div>
    </main>
  )
}
